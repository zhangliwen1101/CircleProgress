/** Automatically generated file. DO NOT MODIFY */
package com.xking.kingcircularindeterminatepb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}